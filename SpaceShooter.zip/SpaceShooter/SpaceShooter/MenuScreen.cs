﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace SpaceShooter
{
    public partial class MenuScreen : Form
    {
        
        WindowsMediaPlayer gameMedia;

        public MenuScreen()
        {
            InitializeComponent();

            // Inicializa o Windows Media Player para reproduzir música de fundo
            gameMedia = new WindowsMediaPlayer();

            // Define o URL do arquivo de música
            gameMedia.URL = "songs\\GameSong.mp3";

            // Configura o modo de repetição para reproduzir continuamente a música
            gameMedia.settings.setMode("loop", true);

            // Configura o volume da música
            gameMedia.settings.volume = 8;

            // Inicia a reprodução da música de fundo
            gameMedia.controls.play();
        }

        private void StartBtn_Click(object sender, EventArgs e)
        {
            // Quando o botão "Start" é clicado, cria uma instância do Form1 (provavelmente o jogo principal)
            Form1 gameWindow = new Form1();

            // Mostra a janela do jogo
            gameWindow.Show();
        }

        private void OptionsBtn_Click(object sender, EventArgs e)
        {
            //OptionsScreen optionsScreen = new OptionsScreen();

            //optionsScreen.Show();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            // Fecha a aplicação quando o botão "Exit" é clicado
            Environment.Exit(1);
        }
    }
}
