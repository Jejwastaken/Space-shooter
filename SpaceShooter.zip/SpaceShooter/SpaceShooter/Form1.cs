﻿using System;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Reflection.Emit;
using System.Windows.Forms;
using WMPLib;

namespace SpaceShooter
{
    public partial class Form1 : Form
    {
        //Declarar objetos Windows Media Player para músicas e efeitos sonoros.
        WindowsMediaPlayer gameMedia;
        WindowsMediaPlayer shootgMedia;
        WindowsMediaPlayer explosion;

        //Declarar arrays de PictureBox para elementos do jogo
        PictureBox[] enemiesMunition;
        int enemiesMunitionSpeed;

        PictureBox[] stars;
        int playerSpeed;

        PictureBox[] munitions;
        int munitionSpeed;

        PictureBox[] enemies;
        int enemySpeed;

        //Variáveis para controlar a velocidade do plano de fundo, nível, pontuação, ect.
        int backgroundspeed;
        Random rnd;

        int score;
        int level;
        int difficulty;
        bool pause;
        bool gameIsOver;

        //Construtor da classe Form1
        public Form1()
        {
            InitializeComponent();
        }

        // Método chamado quando o formulário é carregado
        private void Form1_Load(object sender, EventArgs e)
        {
            //Inicializando variáveis e configurações iniciais
            pause = false;
            gameIsOver = false;
            score = 0;
            level = 1;
            difficulty = 9;

            backgroundspeed = 4;
            playerSpeed = 4;
            enemySpeed = 4;
            munitionSpeed = 20;
            enemiesMunitionSpeed = 4;

            //Inicializa array munições
            munitions = new PictureBox[3];

            //Carregando imagens dos elementos do jogo
            Image munition = Image.FromFile(@"asserts\munition.png");

            Image enemy1 = Image.FromFile("asserts\\E1.png");
            Image enemy2 = Image.FromFile("asserts\\E2.png");
            Image enemy3 = Image.FromFile("asserts\\E3.png");
            Image boss1 = Image.FromFile("asserts\\Boss1.png");
            Image boss2 = Image.FromFile("asserts\\Boss2.png");

            ////Inicializa array enemies
            enemies = new PictureBox[10];

            //Inicializa Enemies PictureBoxes para os inimigos e configura as suas propriedades
            for (int i = 0; i < enemies.Length; i++)
            {
                enemies[i] = new PictureBox();
                enemies[i].Size = new Size(40, 40);
                enemies[i].SizeMode = PictureBoxSizeMode.Zoom;
                enemies[i].BorderStyle = BorderStyle.None;
                enemies[i].Visible = false;
                this.Controls.Add(enemies[i]);
                enemies[i].Location = new Point((i + 1) * 50, -50);
            }

            //Configurando as imagens dos inimigos
            enemies[0].Image = boss1;
            enemies[1].Image = enemy1;
            enemies[2].Image = enemy2;
            enemies[3].Image = enemy3;
            enemies[4].Image = enemy1;
            enemies[5].Image = enemy3;
            enemies[6].Image = enemy2;
            enemies[7].Image = enemy3;
            enemies[8].Image = enemy2;
            enemies[9].Image = boss2;

            //Incializa Munitions PicturesBoxes para as munições do jogador e configura as suas propriedades
            for (int i = 0; i < munitions.Length; i++)
            {
                munitions[i] = new PictureBox();
                munitions[i].Size = new Size(8, 8);
                munitions[i].Image = munition;
                munitions[i].SizeMode = PictureBoxSizeMode.Zoom;
                munitions[i].BorderStyle = BorderStyle.None;
                this.Controls.Add(munitions[i]);
            }

            //CreateWMP
            gameMedia = new WindowsMediaPlayer();
            shootgMedia = new WindowsMediaPlayer();
            explosion = new WindowsMediaPlayer();

            //Load all Songs
            gameMedia.URL = "songs\\GameSong.mp3";
            shootgMedia.URL = "songs\\shoot.mp3";
            explosion.URL = "songs\\boom.mp3";

            //Setup Songs settings
            gameMedia.settings.setMode("loop", true);
            gameMedia.settings.volume = 8;
            shootgMedia.settings.volume = 1;
            explosion.settings.volume = 6;

            //Inicializa array estrelas
            stars = new PictureBox[15];

            //Inicializa o objeto de geração aleatória
            rnd = new Random();

            //Incializa Stars PcituresBoxes para as estrelas e configura as suas propriedades
            for (int i = 0; i < stars.Length; i++)
            {
                stars[i] = new PictureBox();
                stars[i].BorderStyle = BorderStyle.None;
                stars[i].Location = new Point(rnd.Next(20, 500), rnd.Next(-10, 400));
                if (i % 2 == 1)
                {
                    stars[i].Size = new Size(2, 2);
                    stars[i].BackColor = Color.Wheat;
                }
                else
                {
                    stars[i].Size = new Size(3, 3);
                    stars[i].BackColor = Color.DarkGray;
                }
                this.Controls.Add(stars[i]);
            }

            //Enemies Munition para as munições dos inimigos
            enemiesMunition = new PictureBox[10];

            //Incializa enemiesMunitions PicturesBoxes para as munições do inimigo e configura as suas propriedades
            for (int i = 0; i < enemiesMunition.Length; i++)
            {
                enemiesMunition[i] = new PictureBox();
                enemiesMunition[i].Size = new Size(5, 15);
                enemiesMunition[i].Visible = false;
                this.Controls.Add(enemiesMunition[i]);

                // Crie uma imagem para a munição com fundo amarelo
                Bitmap ammoImage = new Bitmap(5, 15);
                using (Graphics g = Graphics.FromImage(ammoImage))
                {
                    g.FillRectangle(Brushes.Yellow, new Rectangle(0, 0, 3, 15)); // Fundo a amarelo
                    g.DrawRectangle(Pens.White, new Rectangle(0, 0, 1, 14)); // Desenhe a borda branca
                }

                enemiesMunition[i].Image = ammoImage;

                int x = rnd.Next(0, 10);
                enemiesMunition[i].Location = new Point(enemies[x].Location.X, enemies[x].Location.Y - 20);
            }
            //Inicia a eprodução da música de fundo
            gameMedia.controls.play();
        }

        //Manipukadores de eventos para temporizadores de movimento
        private void MoveBgTimer_Tick(object sender, EventArgs e)
        {
            //Move as estrelas para simular o plano de fundo em movimento
            for (int i = 0; i < stars.Length/2; i++) 
            {
                stars[i].Top += backgroundspeed;

                if (stars[i].Top >= this.Height)
                {
                    stars[i].Top = -stars[i].Height;
                }
            }

            for (int i = stars.Length / 2; i < stars.Length; i++)
            {
                stars[i].Top += backgroundspeed - 2;

                if (stars[i].Top >= this.Height)
                {
                    stars[i].Top = -stars[i].Height;
                }
            }
        }

        private void LeftMoveTimer_Tick(object sender, EventArgs e)
        {
            //Move o jogador para a esquerda
            if (Player.Left - playerSpeed >= 10)
            {
                Player.Left -= playerSpeed;
            }
        }

        private void RightMoveTimer_Tick(object sender, EventArgs e)
        {
            //Move o jogador para a direita
            if (Player.Right + playerSpeed <= this.ClientSize.Width - 10)
            {
                Player.Left += playerSpeed;
            }
        }

        private void DownMoveTimer_Tick(object sender, EventArgs e)
        {
            //Move o jogador para baixo
            if (Player.Bottom + playerSpeed <= this.ClientSize.Height - 10)
            {
                Player.Top += playerSpeed;
            }
        }

        private void UpMoveTimer_Tick(object sender, EventArgs e)
        {
            //Move o jogador para cima
            if (Player.Top - playerSpeed >= 10)
            {
                Player.Top -= playerSpeed;
            }
        }

        //Manipulador de eventos para o pressionar de teclas       
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (!pause)
            {
                //Inicia temporizadores de movimento com base na tecla pressionada
                if (e.KeyCode == Keys.Right)
                {
                    RightMoveTimer.Start();
                }
                if (e.KeyCode == Keys.Left)
                {
                    LeftMoveTimer.Start();
                }
                if (e.KeyCode == Keys.Down)
                {
                    DownMoveTimer.Start();
                }
                if (e.KeyCode == Keys.Up)
                {
                    UpMoveTimer.Start();
                }
            }
        }
        

        //Manipula eventos para o levantar de teclas
        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            //Para temporizadores de movimento quando as teclas já não estão a ser pressionadas
            RightMoveTimer.Stop();
            LeftMoveTimer.Stop();
            DownMoveTimer.Stop();
            UpMoveTimer.Stop();

            if(e.KeyCode == Keys.Space)
            {
                if (!gameIsOver)
                {
                    if (pause)
                    {
                        //Retoma o jogo se estiver em pausa
                        StartTimer();
                        label.Visible = false;
                        gameMedia.controls.play();
                        pause = false;
                    }
                    else
                    {
                        //Pausando o jogo e exibe uma mensagem de pausa
                        label.Location = new Point(this.Width / 2 - 120, 150);
                        label.Text = "PAUSED";
                        label.Visible = true;
                        gameMedia.controls.pause();
                        StopTimer();
                        pause = true;
                    }
                }
            }
        }


        //Manipula eventos para o temporizador de movimento das munições do jogador
        private void MoveMunitionTimer_Tick(object sender, EventArgs e)
        {
            shootgMedia.controls.play();
            for (int i = 0; i < munitions.Length; i++)
            {
                if (munitions[i].Top > 0)
                {
                    munitions[i].Visible = true;
                    munitions[i].Top -= munitionSpeed;

                    //Verifica se existe colisões entre munições do jogador e inimigos
                    Collison();
                }
                else
                {
                    munitions[i].Visible = false;
                    munitions[i].Location = new Point(Player.Location.X + 20, Player.Location.Y - i * 30);
                }
            }
        }


        //Manipulador de eventos para o temporizador de moviemento dos inimigos
        private void MoveEnemiesTimer_Tick(object sender, EventArgs e)
        {
            MoveEnemies(enemies, enemySpeed);
        }

        //Método para mover um array de PPictureBoxes (inimigos)
        private void MoveEnemies(PictureBox[] array, int speed)
        {
            for (int i = 0; i < array.Length; i++)
            {
                array[i].Visible = true;
                array[i].Top += speed;

                if (array[i].Top > this.Height)
                {
                    array[i].Location = new Point((i + 1) * 50, -200);
                }
            }
        }

        //Método para verificar colisões entre munições do jogador e inimigos
        private void Collison()
        {
            for (int i = 0; i < enemies.Length; i++)
            {
                if (munitions[0].Bounds.IntersectsWith(enemies[i].Bounds) || munitions[1].Bounds.IntersectsWith(enemies[i].Bounds)
                    || munitions[1].Bounds.IntersectsWith(enemies[i].Bounds))
                {
                    explosion.controls.play();

                    //Aumenta a pontuação e atualiza o rótulo de pontuação
                    score += 1;
                    scorelbl.Text = "Score: " + ((score < 10) ? "0" + score.ToString() : score.ToString());

                    //Verifica se o jogador avança de nível com base na pontuação
                    if (score % 30 == 0)
                    {
                        level += 1;
                        levellbl.Text = "Level: " + ((level < 10) ? "0" + level.ToString() : level.ToString());

                        //Aumenta a dificuldade, velocidade do inimigo e velocidade das munições do inimigo
                        if (enemySpeed <= 10 && enemiesMunitionSpeed <= 10 && difficulty >= 0)
                        {
                            difficulty--;
                            enemySpeed++;
                            enemiesMunitionSpeed++;
                        }
                        if (level == 10)
                        {
                            //Exibindo a tela de "Nice Done" se o jogador atingir o nível 10
                            GameOver("Nice Done");
                        }
                    }
                    //Reposiciona o inimigo que foi atingido
                    enemies[i].Location = new Point((i + 1) * 50, -100);
                }
                if (Player.Bounds.IntersectsWith(enemies[i].Bounds))
                {
                    //Toca o som de explosão e encerra o jogo se o jogador colidir com um inimigo
                    explosion.settings.volume = 30;
                    explosion.controls.play();
                    Player.Visible = false;
                    GameOver("");
                }
            }
        }

        //Método para lidar com o fim de jogo
        private void GameOver(string str)
        {
            label.Text = str;
            label.Location = new Point(75, 120);
            label.Visible = true;
            ReplayBtn.Visible = true;
            ExitBtn.Visible = true;

            //Para a música e chama o metodo para para os temporizadores do jogo
            gameMedia.controls.stop();
            StopTimer();
        }

        //Método para para os temporizadores do jogo
        private void StopTimer()
        {
            MoveBgTimer.Stop();
            MoveEnemiesTimer.Stop();
            MoveMunitionTimer.Stop();
            EnemiesMunitionTimer.Stop();
        }

        //Método para iniciar os temporizadores do jogo
        private void StartTimer()
        {
            MoveBgTimer.Start();
            MoveEnemiesTimer.Start();
            MoveMunitionTimer.Start();
            
        }

        //Manipulador de eventos para o temporizador de movimentos das munições dos inimigos
        private void EnemiesMunitionTimer_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < enemiesMunition.Length - difficulty; i++)
            {
                if (enemiesMunition[i].Top < this.Height)
                {
                    enemiesMunition[i].Visible = true;
                    enemiesMunition[i].Top += enemiesMunitionSpeed;
                    if (Player.Bounds.IntersectsWith(enemiesMunition[i].Bounds))
                    {
                        // A colisão ocorreu entre munições dos inimigos e o jogador, chame a função CollisionWithEnemiesMunition
                        CollisionWithEnemiesMunition();
                    }
                }
                else
                {
                    enemiesMunition[i].Visible = false;
                    int x = rnd.Next(0, 10);
                    enemiesMunition[i].Location = new Point(enemies[x].Location.X + 20, enemies[x].Location.Y + 30);
                }
            }
        }

        //Método para lidar com a colisão entre munições dos inimigos e o jogador
        private void CollisionWithEnemiesMunition()
        {
            for (int i = 0; i < enemiesMunition.Length; i++)
            {
                enemiesMunition[i].Visible = false;
                explosion.settings.volume = 30;
                explosion.controls.play();
                Player.Visible = false;
                GameOver("Game Over");
            }
        }

        //Manipulador de eventos para o botão de saída
        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }

        //Manipulador de eventos para o botão de reprodução
        private void ReplayBtn_Click(object sender, EventArgs e)
        {
            //Reiinicializando o jogo
            this.Controls.Clear();
            InitializeComponent();
            Form1_Load(e, e);
        }
    }
}
