﻿namespace SpaceShooter
{
    partial class OptionsScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptionsScreen));
            this.soundOn = new System.Windows.Forms.PictureBox();
            this.soundOff = new System.Windows.Forms.PictureBox();
            this.Volumelb = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.soundOn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soundOff)).BeginInit();
            this.SuspendLayout();
            // 
            // soundOn
            // 
            this.soundOn.Image = ((System.Drawing.Image)(resources.GetObject("soundOn.Image")));
            this.soundOn.Location = new System.Drawing.Point(107, 142);
            this.soundOn.Name = "soundOn";
            this.soundOn.Size = new System.Drawing.Size(90, 96);
            this.soundOn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.soundOn.TabIndex = 0;
            this.soundOn.TabStop = false;
            this.soundOn.Click += new System.EventHandler(this.soundOn_Click);
            // 
            // soundOff
            // 
            this.soundOff.Image = ((System.Drawing.Image)(resources.GetObject("soundOff.Image")));
            this.soundOff.Location = new System.Drawing.Point(247, 142);
            this.soundOff.Name = "soundOff";
            this.soundOff.Size = new System.Drawing.Size(90, 96);
            this.soundOff.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.soundOff.TabIndex = 1;
            this.soundOff.TabStop = false;
            this.soundOff.Click += new System.EventHandler(this.soundOff_Click);
            // 
            // Volumelb
            // 
            this.Volumelb.AutoSize = true;
            this.Volumelb.Font = new System.Drawing.Font("New York Escape Super-Italic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Volumelb.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Volumelb.Location = new System.Drawing.Point(114, 55);
            this.Volumelb.Name = "Volumelb";
            this.Volumelb.Size = new System.Drawing.Size(206, 42);
            this.Volumelb.TabIndex = 4;
            this.Volumelb.Text = "Volume";
            this.Volumelb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Volumelb.Visible = false;
            // 
            // OptionsScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(436, 368);
            this.Controls.Add(this.Volumelb);
            this.Controls.Add(this.soundOff);
            this.Controls.Add(this.soundOn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(452, 407);
            this.Name = "OptionsScreen";
            this.Text = "OptionsScreen";
            ((System.ComponentModel.ISupportInitialize)(this.soundOn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soundOff)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox soundOn;
        private System.Windows.Forms.PictureBox soundOff;
        private System.Windows.Forms.Label Volumelb;
    }
}