﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace SpaceShooter
{
    public partial class OptionsScreen : Form
    {

        //WindowsMediaPlayer gameMedia;
        //WindowsMediaPlayer shootgMedia;
        //WindowsMediaPlayer explosion;

        public OptionsScreen()
        {
            InitializeComponent();

        }

        private void soundOn_Click(object sender, EventArgs e)
        {
            //gameMedia.settings.volume = 0;
            //shootgMedia.settings.volume = 0;
            //explosion.settings.volume = 0;

            //soundOn.Visible = false;
            //soundOff.Visible = true;
        }

        private void soundOff_Click(object sender, EventArgs e)
        {
            //gameMedia.settings.volume = 8;
            //shootgMedia.settings.volume = 1;
            //explosion.settings.volume = 6;

            //soundOn.Visible = true;
            //soundOff.Visible = false;
        }

    }
}
